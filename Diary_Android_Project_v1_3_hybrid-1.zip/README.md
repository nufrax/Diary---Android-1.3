# Diary Android 1.3

Professional hybrid Android shell for the existing Diary web application.

## Included
- Diary branding and launcher icon
- Native splash screen while the web app loads
- HTTPS-only Diary host navigation
- WebView JavaScript + DOM storage + cookies
- File picker for attachments/uploads
- Download manager support for exported files and backups
- Network-aware offline/retry screen
- WebView state restoration after rotation/background recreation
- Android back button follows web history
- Existing release signing workflow for GitHub Actions
- Release APK + AAB build support

## Backend
The Android app continues to use the existing Diary backend at `https://genora.uz/Diary/`. No database migration is required.

## GitHub Actions
Use repository secrets for release signing:
- `DIARY_KEYSTORE_BASE64`
- `DIARY_STORE_PASSWORD`
- `DIARY_KEY_PASSWORD`
- `DIARY_KEY_ALIAS`

Run **Actions → Build Diary Android**. With all four secrets present, the workflow produces both a signed APK and signed AAB. Without them it produces a debug APK fallback.

## Notes
This is a hybrid WebView app rather than a rewrite of the PHP application. This preserves the current backend, login, Notes, Calendar, Tasks, Whiteboard and other Diary features while adding an Android shell around them.

Offline mode provides a connection/retry experience and WebView caching. Full offline editing with later server synchronization is a separate feature and is not claimed here.
